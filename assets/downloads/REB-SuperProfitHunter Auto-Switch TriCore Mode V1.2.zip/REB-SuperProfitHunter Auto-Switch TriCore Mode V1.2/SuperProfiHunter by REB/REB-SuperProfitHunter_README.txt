REB SuperProfitHunter Auto-Switch TriCore Mode V1.2.1

MetaTrader 5 Expert Advisor — README & User Guide

Thank you for choosing REB SuperProfitHunter TriCore Mode, an automated trading Expert Advisor (EA) developed for the ReachEmpireBot ecosystem.

This guide covers the SuperProfitHunter TriCore Mode EA only!

-----------------------

1. About REB SuperProfitHunter TriCore

REB SuperProfitHunter TriCore Mode is an MT5 automated trading EA designed to analyze market conditions, execute supported BUY and SELL strategies, and manage open positions under its configured trading and risk-control rules.

Core functions may include:
- Automated market analysis and BUY/SELL trade execution.
- Single, x2, and x3 trading strategy modes (subject to account eligibility and selected settings).
- Position and basket management.
- Account-based mode restrictions and trading controls.
- ReachEmpireBot account and license authorization.
- Integration with supported ReachEmpireBot monitoring and control functions.

Availability of individual features, including any optional Hedge Lock module, depends on the specific EA build supplied to you. Do not assume that an experimental module is enabled or approved for live trading.

**Platform:** MetaTrader 5 (MT5)
**Product:** REB SuperProfitHunter TriCore
**License Key:** Required

-----------------------

2. Trading Modes and Account Eligibility

Trading modes are manually selected through the supported ReachEmpireBot controls; account balance determines eligibility, not automatic mode selection.

- **Single Mode:** Base volume 0.01 lot; the initial/default mode when the EA is started.
- **x2 Mode:** Base volume 0.02 lot; subject to the applicable balance eligibility check.
- **x3 Mode:** Base volume 0.03 lot; subject to the applicable balance eligibility check.
- **TriCore combination:** Running all three modes together requires an account balance of at least 30,001 USC in the configured cent-account scheme.

Actual volume, eligibility thresholds, available combinations, and behavior should be verified against the supplied EA build and your MT5 account type. **USC is a cent-account unit; it is not the same as USD.**

Trading modes do not guarantee protection against losses, margin calls, or stop-out.

-----------------------

3. License Key & Registration

A valid ReachEmpireBot License Key is required to activate the EA.

Account registration: https://reachempirebot.com/signup

For license assistance:
- Admin / WhatsApp: +855 93 525 363
- Telegram: https://t.me/soungsokheng

-----------------------

4. Install REB SuperProfitHunter TriCore on MT5

1. Launch MetaTrader 5.
2. Select **File > Open Data Folder**.
3. Navigate to **MQL5 > Experts**.
4. Copy the supplied SuperProfitHunter TriCore `.ex5` file to the **Experts** folder. If you received source files (`.mq5` / `.mqh`), install the required dependencies and compile in MetaEditor before use.
5. In MT5, open **Navigator > Expert Advisors**, then select **Refresh** (or restart MT5).
6. Open the trading symbol and chart timeframe supported by your EA build.
7. Attach **REB SuperProfitHunter TriCore** to the chart.
8. Enter the required account/EA ID and License Key. Review any visible Max BUY / Max SELL position limits.
9. Verify settings, the account type, and symbol specification before enabling trading.

-----------------------

5. Allow ReachEmpireBot Server Access

Go to **Tools > Options > Expert Advisors** and enable **Allow WebRequest for listed URL**.

The two uploaded installation documents list these ReachEmpireBot endpoints:
- https://api.reachempirebot.com/
- https://admin.reachempirebot.com/

Add the endpoint(s) required by the **specific EA build** you received. Confirm the required endpoint with ReachEmpireBot support or the EA configuration; the two original guides were inconsistent about which endpoint was mandatory.

Then click **OK**. Keep MT5 connected to the internet to allow license verification and supported synchronization.

-----------------------

6. Activate & Start Trading

1. Attach the EA to an appropriate MT5 chart.
2. Enter your valid License Key and any required account/EA identifier.
3. Check the Expert Advisors settings and enable Algo Trading in MT5 when you intend to permit automated orders.
4. Review **Experts** and **Journal** for authorization, connection, or trading errors.
5. Start on a demo account and confirm that the expected trading mode, lot sizes, and order limits are being applied before considering live operation.

When reattaching or restarting the EA, verify the selected modes again. Existing trades may remain open even when new trade entry is disabled.

-----------------------

7. Monitoring & Risk Controls

- Monitor **Balance, Equity, Free Margin, Margin Level, floating P/L**, and total position exposure.
- Check the account's position limits and permitted trading modes.
- Review **Experts** / **Journal** if the EA does not place or close trades as expected.
- Do not delete MT5 Global Variables, remove EA state, or replace a live EA build with open positions without first reviewing recovery requirements.
- If your build includes Hedge Lock, test its entry/exit, restart recovery, basket profits, and behavior under fast market moves on a demo account before use on a live account.

**Important:** A hedge is not a guarantee against equity drawdown. Unhedged residual exposure, spread, commission, slippage, margin use, and stop-out risk remain possible.

-----------------------

8. Troubleshooting

**EA not visible:** Confirm the `.ex5` file is under MQL5 > Experts, then refresh Navigator or restart MT5.

**License not accepted:** Check account/EA credentials, internet connectivity, and the allowed server URL(s). Contact support if needed.

**EA connected but not trading:** Check Algo Trading, broker permissions, symbol/session availability, mode eligibility, account limits, and the **Experts** log.

**Hedge or position state warning:** Do not delete state or force-close positions without reviewing the order history and the applicable EA build. Preserve the Experts/Journal logs for diagnosis.

-----------------------

9. Risk Warning

Trading Gold, Forex, CFDs, and other leveraged instruments is high risk. Automated trading does not guarantee profit or prevent losses. Results depend on market conditions, broker execution, spread, slippage, liquidity, margin, and settings. Use an appropriately funded demo account for validation and manage live-account exposure responsibly.

-----------------------

10. ReachEmpireBot Support

Registration: https://reachempirebot.com/signup
Admin / WhatsApp: +855 93 525 363
Telegram: https://t.me/soungsokheng

**REB SuperProfitHunter TriCore**
© 2026 ReachEmpireBot. All Rights Reserved.
